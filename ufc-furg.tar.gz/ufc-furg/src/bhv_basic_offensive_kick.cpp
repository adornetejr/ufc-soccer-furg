// -*-c++-*-

/*
 *Copyright:

 Copyright (C) Hidehisa AKIYAMA

 This code is free software; you can redistribute it and/or modify
 it under the terms of the GNU General Public License as published by
 the Free Software Foundation; either version 3, or (at your option)
 any later version.

 This code is distributed in the hope that it will be useful,
 but WITHOUT ANY WARRANTY; without even the implied warranty of
 MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 GNU General Public License for more details.

 You should have received a copy of the GNU General Public License
 along with this code; see the file COPYING.  If not, write to
 the Free Software Foundation, 675 Mass Ave, Cambridge, MA 02139, USA.

 *EndCopyright:
 */

/////////////////////////////////////////////////////////////////////

#ifdef HAVE_CONFIG_H
#include <config.h>
#endif

#include "bhv_basic_offensive_kick.h"

#include <rcsc/action/body_advance_ball.h>
#include <rcsc/action/body_dribble.h>
#include <rcsc/action/body_hold_ball.h>
#include <rcsc/action/body_pass.h>
#include <rcsc/action/neck_scan_field.h>
#include <rcsc/action/neck_turn_to_low_conf_teammate.h>

#include <rcsc/player/player_agent.h>
#include <rcsc/player/debug_client.h>

#include <rcsc/common/logger.h>
#include <rcsc/common/server_param.h>
#include <rcsc/geom/sector_2d.h>

#include <time.h>
#include <iostream>
#include <fstream> 
using namespace std;


using namespace rcsc;

//int estado, r, novo_estado;
/*int R_M[6][6] =   {{0, 1, 2, 3, 4, 5},
			{6, 7, 8, 9, 10, 100},
			{-1, -1, 14, 13, 12, 11},
			{-1, 0, 15, -1, 0, -1},
			{0, 17, 16, 0, -1, 100},
		        {-1, 18, 20, -1, 0, 100}};*/

/*-------------------------------------------------------------------*/
/*!

 */
bool
Bhv_BasicOffensiveKick::execute( PlayerAgent * agent )
{
    dlog.addText( Logger::TEAM,
                  __FILE__": Bhv_BasicOffensiveKick" );

    const WorldModel & wm = agent->world();

    const PlayerPtrCont & opps = wm.opponentsFromSelf();
    const PlayerObject * nearest_opp
        = ( opps.empty()
            ? static_cast< PlayerObject * >( 0 )
            : opps.front() );
    const double nearest_opp_dist = ( nearest_opp
                                      ? nearest_opp->distFromSelf()
                                      : 1000.0 );
    const Vector2D nearest_opp_pos = ( nearest_opp
                                       ? nearest_opp->pos()
                                       : Vector2D( -1000.0, 0.0 ) );


     //Bhv_BasicOffensiveKick::recebeestado(agent);
     //Bhv_BasicOffensiveKick::executaacao(agent);
     //Bhv_BasicOffensiveKick::recompensa(agent);
     //Bhv_BasicOffensiveKick::novoestado(agent);
     /*Atualizar a funcao Q*/
     /*estado = novo estado*/
    
    return true;

}


int 
Bhv_BasicOffensiveKick::recebeestado(PlayerAgent * agent){

    const WorldModel & wm = agent->world();

    const PlayerPtrCont & opps = wm.opponentsFromSelf();
    const PlayerObject * nearest_opp
        = ( opps.empty()
            ? static_cast< PlayerObject * >( 0 )
            : opps.front() );
    const double nearest_opp_dist = ( nearest_opp
                                      ? nearest_opp->distFromSelf()
                                      : 1000.0 );
    const Vector2D nearest_opp_pos = ( nearest_opp
                                       ? nearest_opp->pos()
                                       : Vector2D( -1000.0, 0.0 ) );
    int estado = 0;
    if ( nearest_opp_pos.x < wm.self().pos().x + 1.0 ){//oponente mais proximo atras em X
         if ( nearest_opp_dist > 4.5 ) estado = 1;      
         if ( nearest_opp_dist < 4.5 ) estado = 2;
         if ( nearest_opp_dist < 2.5 ) estado = 3;
    }else{//oponente mais proximo na frente em X
         if ( nearest_opp_dist > 4.5 ) estado = 4;         
         if ( nearest_opp_dist < 4.5 ) estado = 5;
         if ( nearest_opp_dist < 2.5 ) estado = 6;
    }
  
    return estado;
}

int 
Bhv_BasicOffensiveKick::executaacao(PlayerAgent * agent, int acao_q){

    const WorldModel & wm = agent->world();

    const PlayerPtrCont & opps = wm.opponentsFromSelf();
    const PlayerObject * nearest_opp
        = ( opps.empty()
            ? static_cast< PlayerObject * >( 0 )
            : opps.front() );
    int acao = 0;   
    int q = 0;
    const float e = 0.16666667*100; 
   
    //initialize random seed: 
    srand ( time(NULL) );

    //////Politica e-gulosa/////////////////////
    // generate secret number: 
    q = rand() % 100 + 1;
    if(q<=e){
         // generate secret number:
         acao = rand() % 6 + 1;
    }else{
         acao = acao_q;
    }  

   ///////////////////////////////////////////

   ///////Politica aleatoria//////////////////////////////

   //acao = rand() % 6 + 1;   

   /////////////////////////////////////////////////////////  

    Vector2D drib_target( 50.0, wm.self().pos().absY() );
    if ( drib_target.y < 20.0 ) drib_target.y = 20.0;
    if ( drib_target.y > 29.0 ) drib_target.y = 27.0;
    if ( wm.self().pos().y < 0.0 ) drib_target.y *= -1.0;
    const AngleDeg drib_angle = ( drib_target - wm.self().pos() ).th();

    const int max_dash_step = wm.self().playerType().cyclesToReachDistance( wm.self().pos().dist( drib_target ) );
    
    switch(acao){

    case 1:
    
		dlog.addText( Logger::TEAM,
                          __FILE__": (execute) fast dribble to (%.1f, %.1f) max_step=%d",
                          drib_target.x, drib_target.y,
                          max_dash_step );
              agent->debugClient().addMessage( "OffKickDrib(2)" );
               Body_Dribble( drib_target,
                          1.0,
                          ServerParam::i().maxDashPower(),
                          std::min( 5, max_dash_step )
                          ).execute( agent );
             agent->setNeckAction( new Neck_TurnToLowConfTeammate() );
   //           return true;
    break;

    case 2:

            dlog.addText( Logger::TEAM,
                          __FILE__": (execute) slow dribble to (%.1f, %.1f)",
                          drib_target.x, drib_target.y );
            agent->debugClient().addMessage( "OffKickDrib(3)" );
            Body_Dribble( drib_target,
                          1.0,
                          ServerParam::i().maxDashPower(),
                          2
                          ).execute( agent );
        agent->setNeckAction( new Neck_TurnToLowConfTeammate() );
    break;
   
    case 3: 
        dlog.addText( Logger::TEAM,
                      __FILE__": opp far. dribble(%.1f, %.1f)",
                      drib_target.x, drib_target.y );
        agent->debugClient().addMessage( "OffKickDrib(4)" );
        Body_Dribble( drib_target,
                      1.0,
                      ServerParam::i().maxDashPower() * 0.4,
                      1
                      ).execute( agent );
        agent->setNeckAction( new Neck_TurnToLowConfTeammate() );

    break;
    case 4:
        dlog.addText( Logger::TEAM,
                              __FILE__": (execute) do best pass" );
        agent->debugClient().addMessage( "OffKickPass(1)" );
        Body_Pass().execute( agent );
        agent->setNeckAction( new Neck_TurnToLowConfTeammate() );

    break;
    case 5:
        dlog.addText( Logger::TEAM,
                      __FILE__": hold" );
        agent->debugClient().addMessage( "OffKickHold" );
        Body_HoldBall().execute( agent );
        agent->setNeckAction( new Neck_TurnToLowConfTeammate() );

    break;
    //avancar com a bola. 
    case 6:
        dlog.addText( Logger::TEAM,
                      __FILE__": clear" );
        agent->debugClient().addMessage( "OffKickAdvance" );
        Body_AdvanceBall().execute( agent );
        agent->setNeckAction( new Neck_ScanField() );

    break;
}

  
      return acao;
}

int 
*Bhv_BasicOffensiveKick::recompensa(PlayerAgent * agent, int acao_q){

    int R_M[6][6] =   { {-1, -1, -1, 20, -1, -1},
			{0, -1, 0, -1, -1, 0},
			{5, -1, -1, -1, -1, -1},
			{-1, -1, -1, 20, -1, -1},
			{-1, 5, 0, 0, -1, 0},
		        {-1, -1, -1, 10, 10, -1}};//Linhas = Estados, Colunas = Acoes
    
    int *A_E_R;//Matriz de Acao(A)/Estado(S)/Recompensa(R)/Novo Estado(S')
    A_E_R = (int*) malloc(4 * sizeof(int));
    int estado = Bhv_BasicOffensiveKick().recebeestado(agent);
    int acao = Bhv_BasicOffensiveKick().executaacao(agent, acao_q);
    int novo_estado = Bhv_BasicOffensiveKick().recebeestado(agent);  
    int r = R_M[estado-1][acao-1];
    A_E_R[0] = acao;
    A_E_R[1] = estado;
    A_E_R[2] = r;
    A_E_R[3] = novo_estado;
    return A_E_R;
    
}
int 
Bhv_BasicOffensiveKick::novoestado(PlayerAgent * agent){

    const WorldModel & wm = agent->world();

    const PlayerPtrCont & opps = wm.opponentsFromSelf();
    const PlayerObject * nearest_opp
        = ( opps.empty()
            ? static_cast< PlayerObject * >( 0 )
            : opps.front() );
    const double nearest_opp_dist = ( nearest_opp
                                      ? nearest_opp->distFromSelf()
                                      : 1000.0 );
    const Vector2D nearest_opp_pos = ( nearest_opp
                                       ? nearest_opp->pos()
                                       : Vector2D( -1000.0, 0.0 ) );
    int novo_estado = 0;
    if ( nearest_opp_pos.x < wm.self().pos().x + 1.0 ){//oponente mais proximo atras em X
         if ( nearest_opp_dist > 7.0 ) novo_estado = 1;      
         if ( nearest_opp_dist > 4.0 ) novo_estado = 2;
         if ( nearest_opp_dist < 4.0 ) novo_estado = 3;
    }else{//oponente mais proximo na frente em X
         if ( nearest_opp_dist > 7.0 ) novo_estado = 4;         
         if ( nearest_opp_dist > 4.0 ) novo_estado = 5;
         if ( nearest_opp_dist < 4.0 ) novo_estado = 6;
    }
  
      return novo_estado;
}    
